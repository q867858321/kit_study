<template>
    <div class="m_attrNav" @click="get()">
        <h3>组件</h3>
        <el-button  size="small" type="primary" plain @click="addFlippage">Flippage(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>Gallery(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>AppList(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>Infopage(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>Tab(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>Feed(3)<i class="el-icon-plus el-icon--right"></i></el-button>
        <el-button  size="small" type="primary" plain>Advertising(3)<i class="el-icon-plus el-icon--right"></i></el-button>
    </div>
</template>

<script>
export default {
    name:"mAttrNav",
    methods:{
         get:function(){
            console.log("mattrnav",this);
            
            //  this.$http.get('/manage/page/assembly/1').then(function(response){
            //      console.log("response",response.data);
            //  })
        },
        addFlippage:function(){

        }
    }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.m_attrNav{
    padding-bottom:10px;
    border-bottom: 1px solid #eee;
    h3{
        margin-bottom:5px;
    }
}
</style>
