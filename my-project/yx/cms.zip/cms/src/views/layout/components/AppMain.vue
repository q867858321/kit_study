<template>
  <section class="m-app-main app-main">
    <transition name="fade-transform" mode="out-in">
      <keep-alive :include="['Project','Page']">
        <router-view :key="key"/>
      </keep-alive>
    </transition>
  </section>
</template>

<script>
export default {
  name: "AppMain",
  computed: {
    key() {
      return this.$route.fullPath;
    }
  }
};
</script>

<style scoped>
.app-main {
  /*84 = navbar + tags-view = 50 +34 */
  min-height: calc(100vh - 84px);
  width: 100%;
  position: relative;
  /* overflow: hidden; */
}
</style>

